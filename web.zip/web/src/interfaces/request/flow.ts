export interface IDebugSingleRequestBody {
  component_id: string;
  params: any[];
}
