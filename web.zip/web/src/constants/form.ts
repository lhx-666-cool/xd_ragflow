export enum FormLayout {
  Horizontal = 'horizontal',
  Vertical = 'vertical',
  Inline = 'inline',
}
