export enum ChunkTextMode {
  Full = 'full',
  Ellipse = 'ellipse',
}
