export interface ISetLangfuseConfigRequestBody {
  secret_key: string;
  public_key: string;
  host: string;
}
