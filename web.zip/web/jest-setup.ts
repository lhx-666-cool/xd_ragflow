import '@testing-library/jest-dom';
import 'umi/test-setup';
