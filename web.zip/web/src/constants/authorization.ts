export const Authorization = 'Authorization';
export const Token = 'token';
export const UserInfo = 'userInfo';
