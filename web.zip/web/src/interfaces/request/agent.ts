export interface IDebugSingleRequestBody {
  component_id: string;
  params: Record<string, any>;
}
