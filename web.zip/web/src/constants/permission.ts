export enum PermissionRole {
  Me = 'me',
  Team = 'team',
}
