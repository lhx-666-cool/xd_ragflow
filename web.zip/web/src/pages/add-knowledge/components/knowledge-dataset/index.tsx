import { Outlet } from 'umi';

export const KnowledgeDataset = () => {
  return <Outlet></Outlet>;
};

export default KnowledgeDataset;
